/** typing saver. */
public class Generator {
	public static void main( String[] args ) throws Exception {
		com.sun.msv.generator.Driver.main(args);
	}
}
